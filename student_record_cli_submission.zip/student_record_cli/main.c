#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#define DATA_FILE "students.csv"
#define NAME_LEN 80
#define LINE_LEN 256

typedef struct {
    int id;
    char name[NAME_LEN];
    char department[32];
    float cgpa;
} Student;

static void trim_newline(char *s) {
    s[strcspn(s, "\r\n")] = '\0';
}

static int read_line(const char *prompt, char *buffer, size_t size) {
    printf("%s", prompt);
    if (!fgets(buffer, (int)size, stdin)) return 0;
    trim_newline(buffer);
    return 1;
}

static int parse_int(const char *text, int *value) {
    char *end;
    errno = 0;
    long n = strtol(text, &end, 10);
    while (isspace((unsigned char)*end)) end++;
    if (errno || text == end || *end != '\0' || n < 1 || n > 999999) return 0;
    *value = (int)n;
    return 1;
}

static int parse_cgpa(const char *text, float *value) {
    char *end;
    errno = 0;
    float n = strtof(text, &end);
    while (isspace((unsigned char)*end)) end++;
    if (errno || text == end || *end != '\0' || n < 0.0f || n > 10.0f) return 0;
    *value = n;
    return 1;
}

static int valid_text(const char *s) {
    if (s[0] == '\0') return 0;
    for (size_t i = 0; s[i]; i++) {
        if (s[i] == ',' || s[i] == '\n' || s[i] == '\r') return 0;
    }
    return 1;
}

static int id_exists(int id) {
    FILE *fp = fopen(DATA_FILE, "r");
    if (!fp) return 0;
    char line[LINE_LEN];
    while (fgets(line, sizeof line, fp)) {
        Student s;
        if (sscanf(line, "%d,%79[^,],%31[^,],%f", &s.id, s.name, s.department, &s.cgpa) == 4
            && s.id == id) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

static void add_student(void) {
    char line[LINE_LEN];
    Student s;

    if (!read_line("Student ID (1-999999): ", line, sizeof line)) return;
    if (!parse_int(line, &s.id)) {
        puts("Invalid ID. Enter a whole number from 1 to 999999.");
        return;
    }
    if (id_exists(s.id)) {
        puts("That ID already exists.");
        return;
    }

    if (!read_line("Student name: ", s.name, sizeof s.name) || !valid_text(s.name)) {
        puts("Invalid name. It must not be empty or contain commas.");
        return;
    }
    if (!read_line("Department: ", s.department, sizeof s.department) ||
        !valid_text(s.department)) {
        puts("Invalid department. It must not be empty or contain commas.");
        return;
    }
    if (!read_line("CGPA (0.0-10.0): ", line, sizeof line) || !parse_cgpa(line, &s.cgpa)) {
        puts("Invalid CGPA. Enter a number from 0.0 to 10.0.");
        return;
    }

    FILE *fp = fopen(DATA_FILE, "a");
    if (!fp) {
        perror("Could not open data file");
        return;
    }
    if (fprintf(fp, "%d,%s,%s,%.2f\n", s.id, s.name, s.department, s.cgpa) < 0) {
        perror("Could not save student");
        fclose(fp);
        return;
    }
    fclose(fp);
    puts("Student record saved successfully.");
}

static void list_students(void) {
    FILE *fp = fopen(DATA_FILE, "r");
    if (!fp) {
        puts("No records yet. Add a student first.");
        return;
    }

    char line[LINE_LEN];
    int found = 0;
    puts("\nID       NAME                           DEPARTMENT             CGPA");
    puts("---------------------------------------------------------------------");
    while (fgets(line, sizeof line, fp)) {
        Student s;
        if (sscanf(line, "%d,%79[^,],%31[^,],%f", &s.id, s.name, s.department, &s.cgpa) == 4) {
            printf("%-8d %-30s %-22s %.2f\n", s.id, s.name, s.department, s.cgpa);
            found = 1;
        } else {
            fprintf(stderr, "Warning: skipping invalid record in %s\n", DATA_FILE);
        }
    }
    if (!found) puts("No valid records found.");
    fclose(fp);
}

static void search_student(void) {
    char line[LINE_LEN];
    int id, found = 0;
    if (!read_line("Enter student ID to search: ", line, sizeof line)) return;
    if (!parse_int(line, &id)) {
        puts("Invalid ID.");
        return;
    }

    FILE *fp = fopen(DATA_FILE, "r");
    if (!fp) {
        puts("No records yet. Add a student first.");
        return;
    }
    while (fgets(line, sizeof line, fp)) {
        Student s;
        if (sscanf(line, "%d,%79[^,],%31[^,],%f", &s.id, s.name, s.department, &s.cgpa) == 4
            && s.id == id) {
            printf("Found: ID=%d | Name=%s | Department=%s | CGPA=%.2f\n",
                   s.id, s.name, s.department, s.cgpa);
            found = 1;
            break;
        }
    }
    fclose(fp);
    if (!found) puts("Student ID not found.");
}

static void show_menu(void) {
    puts("\n===== STUDENT RECORD MANAGER =====");
    puts("1. Add student");
    puts("2. List students");
    puts("3. Search by ID");
    puts("0. Exit");
}

int main(void) {
    char choice[32];
    for (;;) {
        show_menu();
        if (!read_line("Choose an option: ", choice, sizeof choice)) {
            puts("\nInput closed. Exiting.");
            break;
        }
        if (strcmp(choice, "1") == 0) add_student();
        else if (strcmp(choice, "2") == 0) list_students();
        else if (strcmp(choice, "3") == 0) search_student();
        else if (strcmp(choice, "0") == 0) {
            puts("Goodbye!");
            break;
        } else {
            puts("Invalid option. Choose 1, 2, 3, or 0.");
        }
    }
    return 0;
}
