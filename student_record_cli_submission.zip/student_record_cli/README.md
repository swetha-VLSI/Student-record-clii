# Student Record Manager (C CLI)

A menu-driven command-line application that stores student records in a CSV file. It demonstrates C structs, file handling, input validation, and error handling.

## Features

- Add a student record (ID, name, department, CGPA)
- List saved student records
- Search for a student by ID
- Prevent duplicate IDs
- Validate IDs and CGPA ranges
- Handle missing data files and malformed records
- Store data persistently in `students.csv`

## Requirements

- GCC or another C compiler
- Terminal / command prompt

## Compile

Linux / macOS:
```bash
gcc -Wall -Wextra -std=c11 main.c -o student_manager
```

Windows (MinGW):
```bash
gcc -Wall -Wextra -std=c11 main.c -o student_manager.exe
```

## Run

Linux / macOS:
```bash
./student_manager
```

Windows:
```bash
student_manager.exe
```

The program creates `students.csv` automatically when the first record is added. Keep the CSV file in the same folder as the executable.

## Sample usage

```text
===== STUDENT RECORD MANAGER =====
1. Add student
2. List students
3. Search by ID
0. Exit
Choose an option: 1
Student ID (1-999999): 101
Student name: Arun Kumar
Department: CSE
CGPA (0.0-10.0): 8.7
Student record saved successfully.
```

Example `students.csv`:
```csv
101,Arun Kumar,CSE,8.70
```

## Input rules

- Student ID must be a whole number from 1 to 999999.
- Student IDs must be unique.
- Name and department cannot be empty or contain commas.
- CGPA must be between 0.0 and 10.0.
- Invalid menu options and invalid records are handled with messages.

## Project structure

```text
student_record_cli/
├── main.c
├── README.md
├── sample_students.csv
└── .gitignore
```

## Test checklist

- Add a valid student and list records.
- Try adding the same ID twice.
- Enter text instead of an ID.
- Enter a CGPA below 0 or above 10.
- Search for an ID that does not exist.
- Run list/search before creating `students.csv`.

## Author

Add your name and course details here before submitting.
